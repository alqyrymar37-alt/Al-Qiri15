package com.alqiri.legend

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API key + model name, encrypted at rest with the Android Keystore. */
object SecureStore {
    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences = cached ?: synchronized(this) {
        cached ?: run {
            val app = ctx.applicationContext
            val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, "alqiri_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.also { cached = it }
    }

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "") ?: ""
    /** Blank = "automatic": the brain picks the default model of the detected provider. */
    fun model(ctx: Context): String = prefs(ctx).getString("model", "") ?: ""
    fun baseUrl(ctx: Context): String = prefs(ctx).getString("base_url", "") ?: ""

    fun save(ctx: Context, apiKey: String, model: String, baseUrl: String) {
        prefs(ctx).edit()
            .putString("api_key", apiKey)
            .putString("model", model)
            .putString("base_url", baseUrl)
            .apply()
    }

    fun saveModel(ctx: Context, model: String) {
        prefs(ctx).edit().putString("model", model).apply()
    }

    // ---- Parental control ----
    private fun hash(pin: String): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun hasParentalPin(ctx: Context): Boolean = prefs(ctx).getString("parent_pin", null) != null
    fun setParentalPin(ctx: Context, pin: String) = prefs(ctx).edit().putString("parent_pin", hash(pin)).apply()
    fun checkParentalPin(ctx: Context, pin: String): Boolean = prefs(ctx).getString("parent_pin", null) == hash(pin)
    fun clearParentalPin(ctx: Context) = prefs(ctx).edit().remove("parent_pin").remove("blocked_apps").apply()

    fun blockedApps(ctx: Context): Set<String> = prefs(ctx).getStringSet("blocked_apps", emptySet()) ?: emptySet()
    fun setBlockedApps(ctx: Context, pkgs: Set<String>) = prefs(ctx).edit().putStringSet("blocked_apps", pkgs).apply()

    // ---- Unknown-call detector ----
    fun callDetectorOn(ctx: Context): Boolean = prefs(ctx).getBoolean("call_detector_on", false)
    fun setCallDetectorOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("call_detector_on", on).apply()

    // ---- UI language: "ar" (default) or "en". The AI persona always speaks Yemeni Arabic regardless. ----
    fun appLocale(ctx: Context): String = prefs(ctx).getString("app_locale", "ar") ?: "ar"
    fun setAppLocale(ctx: Context, lang: String) = prefs(ctx).edit().putString("app_locale", lang).apply()
}
